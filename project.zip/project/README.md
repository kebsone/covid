Salut Ibrahima.

J'ai crée la première page. Tu peux en inspirer pour faire la deuxième.

Aussi il faut virer les styles dans les balises html et créer des classes dans le fichier page.css.

J'ai juste fait un capture des image du powerpoint. Tu peux les changer si tu as les originales pour que tout soit plus net.

T'hésites pas si tu d'autres questions
